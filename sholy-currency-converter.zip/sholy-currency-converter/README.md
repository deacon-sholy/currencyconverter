# Currency-Converter
A sholy currency convertion app made with HTML, CSS and Javascript
